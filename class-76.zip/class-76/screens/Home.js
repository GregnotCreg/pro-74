import React, { Component } from 'react';
import { Text, View } from 'react-native';
export default class HomeScrean extends Component{
  render(){
    return(
      <View style={{
        flex:1,
        justifyContent:"center",
        alignItem:"center",
      }}>
      <Text> HomeScreen</Text>
      </View>
    )
  }
}
