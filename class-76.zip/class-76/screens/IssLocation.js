import React, { Component } from 'react';
import { Text, View } from 'react-native';
export default class IssLocationScreen extends Component{
  render(){
    return(
      <View style={{
        flex:1,
        justifyContent:"center",
        alignItem:"center",
      }}>
      <Text> IssLocationScreen</Text>
      </View>
    )
  }
}

